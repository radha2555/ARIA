import React from 'react';
import './App.css'; // Make sure to import the CSS file
import Chat from './Chat';

function App() {
    return (
        <div className="App">
            <Chat />
        </div>
    );
}

export default App;
