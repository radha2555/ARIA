import React, { useState } from 'react';
import './Chat.css'; // Import the CSS file
import responses from './responses'; // Import the responses data

const Chat = () => {
    const [message, setMessage] = useState('');
    const [chatHistory, setChatHistory] = useState([]);

    const getResponse = (key) => {
        const responseArray = responses[key];
        if (Array.isArray(responseArray)) {
            const randomIndex = Math.floor(Math.random() * responseArray.length);
            return responseArray[randomIndex];
        }
        return responses.default[0]; // Default response if key not found
    };

    const generateResponse = (userMessage) => {
        const lowerMessage = userMessage.toLowerCase();

        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return getResponse('greetings');
        } else if (lowerMessage.includes('how are you')) {
            return getResponse('howAreYou');
        } else if (lowerMessage.includes('what is your name')) {
            return getResponse('name');
        } else if (lowerMessage.includes('bye') || lowerMessage.includes('goodbye')) {
            return getResponse('goodbye');
        } else if (lowerMessage.includes('machine learning')) {
            return getResponse('machineLearning');
        } else if (lowerMessage.includes('deep learning')) {
            return getResponse('deepLearning');
        } else if (lowerMessage.includes('code') || lowerMessage.includes('coding')) {
            return getResponse('coding');
        } else if (lowerMessage.includes('roadmap')) {
            if (lowerMessage.includes('python')) {
                return responses.roadmap.python;
            } else if (lowerMessage.includes('javascript') || lowerMessage.includes('js')) {
                return responses.roadmap.javascript;
            } else if (lowerMessage.includes('java')) {
                return responses.roadmap.java;
            } else {
                return "I can provide roadmaps for Python, JavaScript, or Java. Which one do you want?";
            }
        } else if (lowerMessage.includes('python example')) {
            return getResponse('pythonExample');
        } else if (lowerMessage.includes('python')) {
            return responses.programmingLanguages.python;
        } else if (lowerMessage.includes('javascript') || lowerMessage.includes('js')) {
            return responses.programmingLanguages.javascript;
        } else if (lowerMessage.includes('java')) {
            return responses.programmingLanguages.java;
        } else if (lowerMessage.includes('c#') || lowerMessage.includes('c sharp')) {
            return responses.programmingLanguages.csharp;
        } else if (lowerMessage.includes('ruby')) {
            return responses.programmingLanguages.ruby;
        } else {
            return getResponse('default');
        }
    };

    const sendMessage = (e) => {
        e.preventDefault();

        if (message.trim() === '') return; // Prevent sending empty messages

        const userMessage = message;
        const botResponse = generateResponse(userMessage);

        setChatHistory([...chatHistory, { user: userMessage, ai: botResponse }]);
        setMessage('');
    };

    return (
        <div>
            <h1>ARIA: Adaptive Responsive Intelligence Assistant</h1>
            <div className="chat-container">
                {chatHistory.map((entry, index) => (
                    <div key={index} className={`chat-bubble ${entry.user ? 'user-bubble' : 'ai-bubble'}`}>
                        <strong>{entry.user ? 'You' : 'ARIA'}:</strong>
                        <span>{entry.ai.startsWith('```') ? (
                            <div className="code-container">{entry.ai}</div>
                        ) : (
                            entry.ai
                        )}</span>
                    </div>
                ))}
            </div>
            <div className="input-container">
                <form onSubmit={sendMessage}>
                    <input 
                        type="text" 
                        value={message} 
                        onChange={(e) => setMessage(e.target.value)} 
                        placeholder="Type your message..." 
                    />
                    <button type="submit">Send</button>
                </form>
            </div>
        </div>
    );
};

export default Chat;
