const responses = {
    greetings: [
        "Hello! How can I assist you today?",
        "Hi there! What can I do for you?",
    ],
    howAreYou: [
        "I'm just a program, but thanks for asking! How can I help you?",
    ],
    name: [
        "I'm ARIA, your Adaptive Responsive Intelligence Assistant.",
    ],
    goodbye: [
        "Goodbye! Have a great day!",
        "See you later!",
    ],
    machineLearning: [
        "Machine learning is a subset of AI that focuses on building systems that learn from data. Would you like to know more about algorithms or applications?",
    ],
    coding: [
        "I can help you with coding! What programming language are you interested in? I can provide a learning roadmap for Python, JavaScript, or Java.",
    ],
    pythonExample: [
        `Here's a simple example of a machine learning model using Python's scikit-learn library:\n\n\`\`\`python\nfrom sklearn import datasets\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.ensemble import RandomForestClassifier\n\n# Load dataset\ndataset = datasets.load_iris()\nX = dataset.data\ny = dataset.target\n\n# Split data\nX_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)\n\n# Create and train the model\nmodel = RandomForestClassifier()\nmodel.fit(X_train, y_train)\n\n# Make predictions\npredictions = model.predict(X_test)\nprint(predictions)\n\`\`\``,
    ],
    roadmap: {
        python: `### Roadmap to Learning Python:\n1. **Basics:**\n   - Syntax, variables, and data types\n   - Control structures (if, for, while)\n2. **Data Structures:**\n   - Lists, tuples, dictionaries, sets\n3. **Functions:**\n   - Defining and using functions\n4. **Modules and Libraries:**\n   - Using standard libraries like math, datetime\n5. **Object-Oriented Programming:**\n   - Classes and objects\n6. **File Handling:**\n   - Reading and writing files\n7. **Web Development:**\n   - Learn Flask or Django\n8. **Data Science:**\n   - Libraries like NumPy, Pandas, Matplotlib\n9. **Projects:**\n   - Build small projects to practice.\n\nGood resources: [Codecademy](https://www.codecademy.com/learn/learn-python-3), [Coursera](https://www.coursera.org/learn/python).`,
        javascript: `### Roadmap to Learning JavaScript:\n1. **Basics:**\n   - Syntax, variables, and data types\n   - Control structures (if, for, while)\n2. **DOM Manipulation:**\n   - Learn how to manipulate the HTML DOM\n3. **Functions:**\n   - Understanding callbacks and promises\n4. **ES6 Features:**\n   - Arrow functions, let & const, template literals\n5. **Asynchronous JavaScript:**\n   - Learn about async/await, fetch API\n6. **Frameworks:**\n   - Basics of React or Vue.js\n7. **Node.js:**\n   - Build backend services with Node\n8. **Projects:**\n   - Create small projects like a to-do app.\n\nGood resources: [freeCodeCamp](https://www.freecodecamp.org/learn/), [MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/JavaScript).`,
        java: `### Roadmap to Learning Java:\n1. **Basics:**\n   - Syntax, variables, and data types\n   - Control structures (if, for, while)\n2. **Object-Oriented Programming:**\n   - Classes, objects, inheritance\n3. **Data Structures:**\n   - Arrays, ArrayLists, HashMaps\n4. **Exception Handling:**\n   - Try-catch blocks\n5. **Java Collections Framework:**\n   - Lists, sets, maps\n6. **Java Streams:**\n   - Learn about functional programming with streams\n7. **Frameworks:**\n   - Basics of Spring or JavaFX\n8. **Projects:**\n   - Build console-based or GUI applications.\n\nGood resources: [Codecademy](https://www.codecademy.com/learn/learn-java), [Coursera](https://www.coursera.org/learn/java-programming).`,
    },
    default: [
        "I'm not sure how to respond to that. Can you ask something else?",
    ],
};

export default responses;
